import 'package:flutter/material.dart';
import 'package:flutter_login/login.dart';

void main() {
  runApp(const Login());
}

