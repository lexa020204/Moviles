

import 'package:flutter/material.dart';
import 'package:flutter_login/login_info.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {

  String sUsuario = '';
  String sContrasena = '';
  String sMensaje = '';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Login Page'),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
        ),

        body: Center(
          child: Container(
            margin: const EdgeInsets.all(10),
            height: 450,
            child: Column(
              children: [
                const FittedBox(
                  child: FlutterLogo(
                    size: 200,
                    style: FlutterLogoStyle.horizontal,
                  ),
                  
                ),
                TextField(
                  onChanged: (text) {
                    setState(() {
                      sUsuario = text;
                    });
                  },
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Usuario',
                  ),
                ),
                const SizedBox(height: 20),

                TextField(
                  onChanged: (text) {
                    setState(() {
                      sContrasena = text;
                    });
                  },
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Contraseña',
                  ),
                ),
                const SizedBox(height: 20),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    textStyle: const TextStyle(
                      fontSize: 15,
                    ),
                    foregroundColor: Colors.white,
                   
                  ),
                  onPressed: () async {
                    await LoginInfo().enviarInfo(sUsuario, sContrasena);
                  },
                  child: const Text('Ingresar'),
                ),

                Text(sMensaje),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
