import fetch from 'node-fetch';

export async function getProducts(){    
    try{
        const response = await fetch('https://api.npoint.io/88abc1f40845fe530fd4');
        const products = await response.json();
         return products;
    }
    catch{
        return [];  
    }
 
}
