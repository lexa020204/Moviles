
export async function compareCredentials(email,contrasena){
    const users = [
        {
            usuario: 'admin@gmail.com',
            contrasena: 'admin',
        },
        {
            usuario: 'admin2',
            contrasena: 'admin2',}
    ];
    if (users.find(user => user.usuario === email && 
        user.contrasena === contrasena)){
            return true;
    }
    else{
        return false;
        
}

}

